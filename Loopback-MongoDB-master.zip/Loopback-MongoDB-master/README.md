# Loopback-MongoDB
Menghubungkan antara Loopback dengan MongoDB
